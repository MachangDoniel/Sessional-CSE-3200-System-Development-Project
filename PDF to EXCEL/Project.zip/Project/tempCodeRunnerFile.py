 match_name = str(match_name).replace(' ', '').replace('.', '').replace(',', '')
                                matches = [file for file in os.listdir(output_dir) if match_name in file]